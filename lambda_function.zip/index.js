const axios = require("axios");
const AWS = require('aws-sdk');

const dynamoDb = new AWS.DynamoDB.DocumentClient();

let myVar;

async function getRandomNumber() {
  return Math.floor(Math.random() * 20) + 1;
}

async function insertToDynamo(payload) {
  try {
    const params = {
      TableName: 'cache-table',
      Item: {
        id: payload.id,
        payload: payload
      }
    };
    // write the record to DynamoDB
    await dynamoDb.put(params).promise();
    console.log(`Record with id ${params.Item.id} was added to DynamoDB.`);
  } catch (error) {
    console.error(error);
  }
}

console.log(getRandomNumber());

async function getvalue() {
  try {
    let number = await getRandomNumber();
    const response = await axios.get(
      `https://jsonplaceholder.typicode.com/todos/${number}`
    );
    console.log(response.data);
    insertvalue = await insertToDynamo(response.data);

    myVar = {
      statusCode: 200,
      body: JSON.stringify(response.data),
    };
    return myVar;
  } catch (error) {
    console.error(error);
    myVar = {
      statusCode: 500,
      body: JSON.stringify({ message: "An error occurred" }),
    };
    return myVar;
  }
}
exports.handler = async (event, context) => {
  if (!myVar) {
    console.log("IN MYVAR");
    myVar = await getvalue();
  }
  console.log(`here you go: ${myVar.body}`);
};
